<?php

session_start();
$idclass=$_POST['idclass'];
$name=$_SESSION['message'];

if($name=="")

{header('Location:/authorization.php');
exit();}

else {
  $servername = "localhost:3307";
  $database = "yogahall";
  $username = "root";
  $password = "root";
  // Создаем соединение

  $conn = mysqli_connect($servername, $username, $password, $database);
  // Проверяем соединение
  if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
  }


  $iduser=$conn->query("SELECT iduser from users where name='$name'");
  $idus=$iduser->fetch_assoc();
  $iduserc=$idus['iduser'];

  $conn->query("insert into note(iduser,idclass) values ('$iduserc','$idclass')");

  $mailik=$conn->query("SELECT email from users where name='$name'");
  $mail=$mailik->fetch_assoc();
  $email=$mail['email'];

  $result=$conn -> query("SELECT fio, type_of_yoga ,date, time from
  classes inner join teachers on classes.idteacher=teachers.idteacher
  inner join types_of_yoga on classes.idtype=types_of_yoga.idtype where
   idclass='$idclass' ");

   $class=$result->fetch_assoc();
     $fio=$class['fio'];
      $typic=$class['type_of_yoga'];
      $dayy=$class['date'];
      $ttime=$class['time'];




   $subject="=?utf-8?B?".base64_encode("Yogahall")."?=";
   $headers="From:$email\r\nReply-to: $email\r\nContent-type:text/html;charset=utf-8\r\n";
   $message="Доброго дня! Это письмо является подтверждением записи на занятие в нашей студии,подробнее:
   вы записаны на $dayy в $ttime  к преподавателю $fio , вид йоги: $typic ";

   mail($email,$subject, $message, $headers);


  $conn->close();

 header('Location:/gotovo.php');
}






?>
