<?php

$idclass = filter_var(trim($_POST['idclass']),
FILTER_SANITIZE_STRING);

$servername = "localhost:3307";
$database = "yogahall";
$username = "root";
$password = "root";
// Создаем соединение

$conn = mysqli_connect($servername, $username, $password, $database);
// Проверяем соединение
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}


echo $idclass;

$conn -> query("DELETE from   classes  where
 classes.idclass='$idclass' ");


 

header('Location: /director.php');

?>
