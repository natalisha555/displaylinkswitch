<!DOCTYPE HTML >
<html lang="ru">
 <head>
  <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<meta http-equiv="X-UA-Compatible" content="ie=edge">

<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="dns-prefetch" href="//netdna.bootstrapcdn.com">

	<title> PHP web-site</title>


 </head>

 <body>

	<?php require "blocks/header.php" ?>
<p >
  <img  class="fig" src="img/logosvg.svg" alt="Logo">
</p>

<style>
.fig{
margin-left:400px;
height:170px;
}
 </style>




	 <div class="so-widget-sow-editor so-widget-sow-editor-base">
 <div class="siteorigin-widget-tinymce textwidget">
 	<h2 class="tex" >О студии</h2>

 <p class="tex" >Студия <strong>YogaHall</strong> – это уютная студия йоги рядом с метро ст. Якуба Коласа. На наших практиках группы по 8-12 человек. Преподаватель уделяет каждому присутствующему должное внимание для правильного выполнения асан, помогает с отстройкой или советует выполнить более простую версию асаны, помогает словить равновесие. Ведь все эти вещи гораздо проще сделать в маленькой группе, а не в большой, где вы можете затеряться или так и не дождаться преподавателя. В студии два зала, есть релакс-зона, где вы можете после занятия выпить ароматного чаю и пообщаться с преподавателем или друзьями по группе. У нас есть весь основной инвентарь для занятий йогой. Для вашей комфортной практики: утолщенные коврики, блоки, ремни, подушки для медитации, пледы и болстеры.</p>

<style>
.tex{margin-left:70px;
margin-right:70px;}
</style>

 <p >
   <img  class="fig2" src="img/11.jpg" alt="Logo">
 </p>

 <style>
 .fig2{
 margin-left:70px;
 width:1100px;
 height:700px;
 }
  </style>
  <h2 class="tex">Наши преимущества</h2>

  <div class="container mt-5">
  <div class="row row-cols-1 row-cols-md-3 mb-3 text-center">
    <div class="col">
      <div class="card mb-4 rounded-3 shadow-sm">

        <div class="card-body">
            <img src="http://yogahall.by/wp-content/uploads/2017/08/icon-5.png" class="img-thumbnail" alt="">
  <figcaption>Удобное месторасположение (около 50 метров от метро Я.Коласа) </figcaption>
          <h1 class="card-title pricing-card-title"><small class="text-muted fw-light"></small></h1>
          <ul class="list-unstyled mt-3 mb-4">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
          </ul>

        </div>
      </div>
    </div>

    <div class="col">
        <div class="card mb-4 rounded-3 shadow-sm">
          <div class="card-body">
            <img src="http://yogahall.by/wp-content/uploads/2017/08/icon-4.png" class="img-thumbnail" alt="">
            <figcaption>Только сертифицированные специалисты</figcaption>
            <h1 class="card-title pricing-card-title"><small class="text-muted fw-light"></small></h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li></li>
              <li></li>
              <li></li>
              <li></li>
            </ul>

          </div>
        </div>
      </div>

      <div class="col">
        <div class="card mb-4 rounded-3 shadow-sm">
          <div class="card-body">
              <img src="http://yogahall.by/wp-content/uploads/2017/08/icon-2.png" class="img-thumbnail" alt="">
                <figcaption>Более 8 видов йоги для любых запросов и уровня подготовки, утренняя и вечерняя йога.</figcaption>
            <h1 class="card-title pricing-card-title"><small class="text-muted fw-light"></small></h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li></li>
              <li></li>
              <li></li>
              <li></li>
            </ul>

          </div>
        </div>
      </div>

      <div class="col">
        <div class="card mb-4 rounded-3 shadow-sm">

          <div class="card-body">
              <img src="http://yogahall.by/wp-content/uploads/2017/08/icon-3.png" class="img-thumbnail" alt="">
                <figcaption>Чайная зона с вкусным травяным чаем, полезным печеньем и бесплатным WI-FI.</figcaption>
            <h1 class="card-title pricing-card-title"><small class="text-muted fw-light"></small></h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li></li>
              <li></li>
              <li></li>
              <li></li>
            </ul>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card mb-4 rounded-3 shadow-sm">
          <div class="card-body">
              <img src="http://yogahall.by/wp-content/uploads/2017/08/icon-1.png" class="img-thumbnail" alt="">
                 <figcaption>Маленькие группы с внимательным преподавателем.</figcaption>
            <h1 class="card-title pricing-card-title"><small class="text-muted fw-light"></small></h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li></li>
              <li></li>
              <li></li>
              <li></li>
            </ul>

          </div>
        </div>
      </div>



      <div class="col">
        <div class="card mb-4 rounded-3 shadow-sm">

          <div class="card-body">
              <img src="http://yogahall.by/wp-content/uploads/2017/08/icon-6.png" class="img-thumbnail" alt="">
                <figcaption> В студии домашний уют и всегда дружелюбная атмосфера.</figcaption>

            <h1 class="card-title pricing-card-title"><small class="text-muted fw-light"></small></h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li></li>
              <li></li>
              <li></li>
              <li></li>
            </ul>

          </div>
        </div>
      </div>


    </div>
  </div>



  <p >
    <img  class="fig2" src="img/12.jpg" alt="Logo">
  </p>

  <style>
  .fig2{
  margin-left:70px;
  width:1100px;
  height:700px;
  }
   </style>

   <h3 class="tex"> Атмосфера</h3>
   <p class="tex">Интерьер выполнен в цветах природы (зеленый, желтый, коричневый, бежевый) для того, чтобы при нахождении в студии вы отвлекались от суматохи на работе или от бытовых забот дома. Мы стараемся создавать дружескую атмосферу, чтобы вы могли не только заниматься йогой, но и приятно общаться с друзьями после практик за чашкой чая в нашей релакс-зоне или прогуляться по парку, который находится через дорогу от студии (здесь в летнее время мы проводим занятия по йоге на свежем воздухе). В студии установлена мощная система кондиционирования. В жаркие летние дни можно, либо открывать окна, для притока свежего воздуха, либо включать кондиционер: принудительно вентилировать воздух уличной температуры (не нарушая тишину во время медитации), либо немного охладить зал, чтобы практиковать было комфортнее. А зимой температура воздуха в помещении всегда около 22-24 °C.</p>
  <p >

<style>
.tex{margin-left:70px; }
</style>

     <img  class="fig2" src="img/13.jpg" alt="Logo">
   </p>

   <style>
   .fig2{
   margin-left:70px;
   width:1100px;
   height:700px;
   }
    </style>




 <h3 class="tex" >Наши преподаватели</h3>
 <p class="tex">Для многих из наших преподавателей занятия йогой это любимое хобби, а не просто работа. У всех преподавателей есть сертификаты, они посещают различные семинары и постоянно развиваются. Для них это не просто физическая практика, которая приведет ваши мышцы в тонус. С помощью йоги они вас научат чувствовать ваше тело, помогут успокоить ваш "шумящий" ум, избавят от болей в спине и вернут обратно здоровый и крепкий сон. Каждый преподаватель по йоге скажет, если вы постоянно занимаетесь, то</p>


 <ul class="tex">
 <li>улучшаете физическую форму</li>
 <li>снимаете стресс и расслабляетесь</li>
 <li>устраняете сонливость и вялость</li>
 <li>увеличиваете выносливость</li>
 <li>усиливаете концентрацию</li>
 <li>тело становится пластичным и гибким</li>
 <li>укрепляете иммунитет</li>
 <li>предупреждаете болезни суставов.</li>
 </ul>

 </div>
 </div>
 <style>
 .tex{margin-left:70px;
 margin-right:70px;}
 </style>

 	<?php require "blocks/footer.php" ?>

 </body>
</html>
