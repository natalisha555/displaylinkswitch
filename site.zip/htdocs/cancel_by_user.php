<?php

$idclass = filter_var(trim($_POST['idclass']),
FILTER_SANITIZE_STRING);


session_start();
$nam=$_SESSION['message'];


$servername = "localhost:3307";
$database = "yogahall";
$username = "root";
$password = "root";
// Создаем соединение

$conn = mysqli_connect($servername, $username, $password, $database);
// Проверяем соединение
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$result=$conn -> query("SELECT iduser from users where name='$nam' ");
$class=$result->fetch_assoc();
$idus=$class['iduser'];


$conn -> query("DELETE from   note  where
 idclass='$idclass' and iduser='$idus' ");

header('Location: /gotovo2.php');

?>
