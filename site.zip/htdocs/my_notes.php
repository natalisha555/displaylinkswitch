<!DOCTYPE HTML >
<html lang="ru">
 <head>
  <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<meta http-equiv="X-UA-Compatible" content="ie=edge">

<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="dns-prefetch" href="//netdna.bootstrapcdn.com">

	<title> PHP web-site</title>
 </head>
 <body>

	<?php require "blocks/header.php" ?>


      <?php

      $nam = $_GET["name"];


      $servername = "localhost:3307";
      $database = "yogahall";
      $username = "root";
      $password = "root";
      // Создаем соединение

      $conn = mysqli_connect($servername, $username, $password, $database);
      // Проверяем соединение
      if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
      }

    $i=0;

    $result=$conn -> query("SELECT iduser from users where name='$nam' ");
  $class=$result->fetch_assoc();


$id=$class['iduser'];


    $result=$conn -> query("SELECT idclass from note where iduser='$id' ");


      ?>


            <div class="container mt-5">

            <div class="row row-cols-1 row-cols-md-3 mb-3 text-center">
               <?php

               while($rws = mysqli_fetch_assoc($result)) {

              $m=$rws['idclass'];


               $result2=$conn -> query("SELECT cl.idclass as idclass,fio, type_of_yoga ,date, time from
                  classes as cl inner join note as nt on cl.idclass=nt.idclass
                  inner join teachers as tch on cl.idteacher=tch.idteacher
                  inner join types_of_yoga as ty on cl.idtype=ty.idtype
                  where cl.idclass='$m' ");


               $class2=$result2->fetch_assoc();


                ?>
              <div class="col">

                <div class="card mb-4 rounded-3 shadow-sm">
                  <div class="card-header py-3">
                    <h4 class="my-0 fw-normal"><?php echo $class2['type_of_yoga'] ?></h4>
                  </div>
                  <div class="card-body">
                  <img src="img/<?php $i++; echo $i; ?>.jpg" class="img-thumbnail" alt="">
                    <h1 class="card-title pricing-card-title"><small class="text-muted fw-light"></small></h1>
                    <ul class="list-unstyled mt-3 mb-4">
                      <li><?php  echo "Преподаватель: "; echo $class2['fio'] ?></li>
                      <li><?php  echo "Время: "; echo $class2['time']; $idclass=$class2['idclass']?>           </li>
                      <li>  <?php  echo "Дата: "; echo $class2['date']; ?>      </li>
                      <li></li>
                    </ul>




          <form action="cancel_by_user.php"  method="post">
              <input type="hidden"  name="idclass" value="<?php echo  $idclass?>"  ><br>

          <button type="submit" class="w-100 btn btn-danger btn-primary" >Отменить</button>
        </form>



                  </div>
                </div>
              </div>
          <?php } ?>
              </div>

            </div>






 	<?php require "blocks/footer.php" ?>

 </body>
</html>
