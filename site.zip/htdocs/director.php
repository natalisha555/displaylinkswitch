<?php
include "read_and_export2.php";
?>

<!DOCTYPE HTML >
<html lang="ru">
 <head>
  <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<meta http-equiv="X-UA-Compatible" content="ie=edge">

<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="dns-prefetch" href="//netdna.bootstrapcdn.com">

	<title> PHP web-site</title>
 </head>
 <body style="background-color:aquamarine">

	<?php require "blocks/header.php" ?>


  <h3 class="mb-5 kol"  style="font-style:italic; margin-left:450px; " ><font color="indigo">
      Добрый день!</font></h3>

      <?php
      $servername = "localhost:3307";
      $database = "yogahall";
      $username = "root";
      $password = "root";
      // Создаем соединение

      $conn = mysqli_connect($servername, $username, $password, $database);
      // Проверяем соединение
      if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
      }

$i=0;
      $result=$conn->query("SELECT  type_of_yoga from types_of_yoga ");

      $mass = array();
      while($rws = mysqli_fetch_assoc($result)){
        $mass[$i] = $rws['type_of_yoga'];
        $i++;
      }
//print_r($mass);
      $sortik=array();
      $sortik=array_unique($mass, SORT_STRING);
      $n=mysqli_num_rows($result);


$i=0;
      $result2=$conn->query("SELECT  fio from teachers ");

      $mass2 = array();
      while($rws2 = mysqli_fetch_assoc($result2)){
        $mass2[$i] = $rws2['fio'];
        $i++;
      }
      //print_r($mass);
      $sortik2=array();
      $sortik2=array_unique($mass2, SORT_STRING);
      $k=mysqli_num_rows($result2); ?>

      <div class="container">
      <br>
      <div class="col-sm-12">
      <div>
      <form action="#" method="post" class="color">
      <button type="submit" id="export" name="export2"
      value="Export to excel" class="btn color btn-success">Экспорт расписания преподавателей в Excel</button>
      </form>
      </div>
      </div>
      <br/><br>





<table  id="" class=" hidde table  table-striped table-bordered">
<tr>
<th>Дата</th>
<th>Преподаватель</th>
<th>Вид йоги</th>

<th>Время</th>
</tr>
<tbody>
  <?php
      $m=$classes[0]['date'];

      foreach($classes as $class) { ?>
      <tr>
      <td><?php if($class ['date']!=$m)
      { $class['date']= $class ['date'];
      $m=$class ['date'];}
      else { $class['date']="";
      }
       ?></td>
<td><?php echo $class ['fio']; ?></td>
<td><?php echo $class ['type']; ?></td>
<td>$<?php echo $class ['time']; ?></td>
</tr>
<?php } ?>
</tbody>
</table>

</div>


    <style>
    .hidde{
      display:none;
    }
    .color{
      margin-left:-150px;
      margin-top:-70px;
      margin-bottom:-100px;
      width:200px;
      color:blue;
    }
    .len{
      margin-left:300px;
        margin-top:-70px;
        margin-right:350px;
    }
    </style>
<div class="len">
 <h2 class="s"> Редактируйте классы </h2>
     <form action="vybor.php" class="size" method="post">
         <h3> Выберите дату класса</h3>
         <input type="date" class="form-control" name="date" id="date" placeholder="Введите дату занятия " ><br>


         <h3> Выберите направление йоги</h3>
         <select class="l" name="type">

         <?php  $j=0; while($sortik[$j]) {        ?>

         <option value="<?php echo $sortik[$j] ?>"><?php echo $sortik[$j] ; $j++;?></option>
       <?php }?>
         </select> <br> <br>


         <h3> Выберите преподавателя</h3>
         <select  class="l" name="teach">
           <?php  $j=0; while($sortik2[$j]) {        ?>

           <option value="<?php echo $sortik2[$j] ?>"><?php echo $sortik2[$j] ; $j++;?></option>
         <?php }?>
         </select> <br> <br>
         <button   type="submit" class="btn btn-success">Просмотреть классы</button>
         </form>

</div>




<br>


<div class="container cl mt-5">
  <h3>Контактная форма</h3>
  <form action="once_post.php" method="post">
    <select class="l" name="post">
  <option selected>выберите кому</option>
  <option value="s">всем сотрудникам</option>
  <option value="c">всем клиентам</option>
  <option value="cs">всем сотрудникам и клиентам</option>
  </select> <br> <br>
<textarea name="message" class="form-control"
placeholder="Введите ваше быстрое сообщение"></textarea><br>
<button type="submit" name="send" class="btn btn-success">Отправить</button>
</form>

</div>


<style>
.kol{ margin-left:150px;}
.size{
  width:350px;
  height:300px;
  margin-left:100px;
}
.s{
  margin-left:100px;
  margin-top:100px;
}
.cl{
  background-color:Turquoise;
  margin-right:450px;
  margin-left:350px;
}
</style>
<br>

 	<?php require "blocks/footer.php" ?>

 </body>
</html>
