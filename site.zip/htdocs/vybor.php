<!DOCTYPE HTML >
<html lang="ru">
 <head>
  <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<meta http-equiv="X-UA-Compatible" content="ie=edge">

<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="dns-prefetch" href="//netdna.bootstrapcdn.com">

	<title> PHP web-site</title>
 </head>
 <body>

	<?php require "blocks/header.php" ?>


      <?php

      $teach = filter_var(trim($_POST['teach']),
      FILTER_SANITIZE_STRING);
      $type = filter_var(trim($_POST['type']),
      FILTER_SANITIZE_STRING);
      $date = filter_var(trim($_POST['date']),
      FILTER_SANITIZE_STRING);


      $servername = "localhost:3307";
      $database = "yogahall";
      $username = "root";
      $password = "root";
      // Создаем соединение

      $conn = mysqli_connect($servername, $username, $password, $database);
      // Проверяем соединение
      if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
      }

    $i=0;

    $result=$conn -> query("SELECT idclass,fio, type_of_yoga ,date, time from
     classes inner join teachers on classes.idteacher=teachers.idteacher
     inner join types_of_yoga on classes.idtype=types_of_yoga.idtype where
     classes.date='$date' and teachers.fio='$teach' and types_of_yoga.type_of_yoga='$type' ");



    $class=$result->fetch_all();

echo $class['type_of_yoga'];

      ?>



      <div class="container mt-5">

      <div class="row row-cols-1 row-cols-md-3 mb-3 text-center">
         <?php foreach($class as $cl): ?>
        <div class="col">

          <div class="card mb-4 rounded-3 shadow-sm">
            <div class="card-header py-3">
              <h4 class="my-0 fw-normal"><?php echo $cl[2] ?></h4>
            </div>
            <div class="card-body">
            <img src="img/<?php $i++; echo $i; ?>.jpg" class="img-thumbnail" alt="">
              <h1 class="card-title pricing-card-title"><small class="text-muted fw-light"></small></h1>
              <ul class="list-unstyled mt-3 mb-4">
                <li><?php  echo "Преподаватель: "; echo $cl[1] ?></li>
                <li><?php  echo "Время: "; echo $cl[4]; $idclass=$cl[0]?>           </li>
                <li></li>
                <li></li>
              </ul>

              <form action="change_classes.php"  method="post">
    <input type="hidden"  name="idclass" value="<?php echo  $idclass?>"  ><br>
  <button type="submit" class="w-100 btn btn-lg btn-primary">Изменить </button>
  </form>


    <form action="cancel_class.php"  method="post">
        <input type="hidden"  name="idclass" value="<?php echo  $idclass?>"  ><br>

    <button type="submit" class="w-100 btn btn-danger btn-primary" >Отменить</button>
  </form>



            </div>
          </div>
        </div>
    <?php endforeach ?>
        </div>

      </div>





<style>
.kol{ margin-left:150px;}
</style>


 	<?php require "blocks/footer.php" ?>

 </body>
</html>
