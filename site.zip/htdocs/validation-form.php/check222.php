<?php
//print_r($_POST);
$email=$_POST['email'];
$message=$_POST['message'];


$error='';
if(trim($email)=='')
$error='Введите ваш email';
else if (trim($message)=='')
$error='Введите само сообщение';
else if(strlen($message)<20)
$error='Cообщение должно быть больше 20 символов';


if($error!=''){
  echo $error;
  exit;
}

$subject="=?utf-8?B?".base64_encode("Yogahall")."?=";
$headers="From:natadesu@yandex.ru\r\nReply-to: $email\r\nContent-type:text/html;charset=utf-8\r\n";

mail('natadesu@yandex.ru',$subject, $message, $headers);

header('Location: /validaz.php');

exit();

 ?>
