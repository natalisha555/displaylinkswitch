<?php
require_once "class1.php";

  $Mama=new Person(1,'Nata','Dzes',2000-11-11,1,'Gomel');

?>
