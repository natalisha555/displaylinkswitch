<?php
$teach= filter_var(trim($_POST['teach']),  FILTER_SANITIZE_STRING);

session_start();
$user=$_SESSION['message'];


$prof=filter_var(trim($_POST['health']),  FILTER_SANITIZE_STRING);
$cly=filter_var(trim($_POST['mood']),  FILTER_SANITIZE_STRING);
$comun=filter_var(trim($_POST['general']),  FILTER_SANITIZE_STRING);

$imp1=filter_var(trim($_POST['imp1']),  FILTER_SANITIZE_STRING);
$imp2=filter_var(trim($_POST['imp2']),  FILTER_SANITIZE_STRING);
$imp3=filter_var(trim($_POST['imp3']),  FILTER_SANITIZE_STRING);


$servername = "localhost:3307";
$database = "yogahall";
$username = "root";
$password = "root";
// Создаем соединение

$conn = mysqli_connect($servername, $username, $password, $database);
// Проверяем соединение
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$iduser=$conn->query("SELECT iduser from users where name='$user'");
$idus=$iduser->fetch_assoc();
$iduserc=$idus['iduser'];

$conn->query("insert into rates(iduser, idteacher,proficiency, clientorint, communication, imp1, imp2,imp3) values ('$iduserc','$teach','$prof', '$cly', '$comun', '$imp1','$imp2','$imp3')");

mysqli_close($conn);

header("Location:saati.php");





?>
