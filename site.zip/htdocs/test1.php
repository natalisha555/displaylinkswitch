<?php
    // объявляем класс с именем Rectangle
    class Rectangle
    {
        // свойство "ширина"
        private $width;
        // свойство "высота"
        private $height;

        // конструктор класса
        public function __construct($x, $y)
        {
            $this->width = $x;
            $this->height = $y;
        }

        // метод "посчитать площадь"
        public function Square()
        {
            return $this->width * $this->height;
        }
    }

    // создаём массив прямоугольников
    //$rects = array();
    // заполняем массив экземплярами
    $rects = new Rectangle(100, 100);
  //  $rects['2'] = new Rectangle(20, 200);
  //  $rects['3'] = new Rectangle(300, 50);

    // выводим площадь каждого экземпляра
  //  foreach($rects as $key => $rect)
    //{
      //  echo 'Площадь ' . $key .
          //      ' прямоугольника: ' . $rect->Square() .
            //    ">br />\n";
  //  }
?>
