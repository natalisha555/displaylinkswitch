
<?php

include 'lib.php';
Mailer()->init(include 'config.php');

$message = Mailer()->newHtmlMessage();

$message->setSubject('Global');
$message->setSenderEmail('natadesu@yandex.ru');
$message->addRecipient('alisonka549555@gmail.com');

//$message->addContent(file_get_contents('mail-header.html'));
$message->addContent('Hii');
//$message->addContent(file_get_contents('mail-footer.html'));

//$message->addRelatedFile('signature.png');


Mailer()->sendMessage($message);

?>
