<!DOCTYPE HTML >
<html lang="ru">
 <head>

  <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">

<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="dns-prefetch" href="//netdna.bootstrapcdn.com">

<title> PHP web-site</title>

<style type="text/css">
BODY {
background:#338 ; /* Параметры фона */
}
.n{
  margin-left:400px;
  margin-top: 150px;
}
.l{
  background:pink;
}
</style>


 </head>
 <body>


	<?php require "blocks/header.php" ?>
  <div class="n">
<h1> Оцените то, что для вас важно!</h4>
  <br> <br>
  <form action="vybor_po_krit.php" method="post">

<h3> Выберите, что является наиболее важным для вас при выборе преподавателя</h3>
  <select class="l" name="type">
<option selected></option>
<option value="prof">профессионализм</option>
<option value="cly">клиентоориентированность</option>
<option value="comun">коммуникация</option>

</select> <br> <br>
<h3> Выберите, что для вас имеет среднюю важность</h3>
  <select class="l" name="type1">
<option selected></option>
<option value="prof">профессионализм</option>
<option value="cly">клиентоориентированность</option>
<option value="comun">коммуникация</option>
</select> <br> <br>
<h3> Выберите, что для вас наименее важно</h3>
  <select  class="l" name="type2">
<option selected></option>
<option value="prof">профессионализм</option>
<option value="cly">клиентоориентированность</option>
<option value="comun">коммуникация</option>

</select> <br> <br>
<button   type="submit" class="btn btn-success">Подобрать преподавателя!</button>
  </form>

</div>




   </body>
  </html>
