<!DOCTYPE HTML >
<html lang="ru">
 <head>
  <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<meta http-equiv="X-UA-Compatible" content="ie=edge">

<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="dns-prefetch" href="//netdna.bootstrapcdn.com">
	<title> PHP web-site</title>

 </head>

 <body>

	<?php require "blocks/header.php" ?>

  <div class="container mt-5">
    <h3>Контактная форма</h3>
    <form action="validation-form.php/check222.php" method="post">
      <input type="email" name="email" placeholder="Введите email"
  class="form-control"><br>
  <textarea name="message" class="form-control"
  placeholder="Введите ваше сообщение"></textarea><br>
  <button type="submit" name="send" class="btn btn-success">Отправить</button>
  </form>

  	<div class="align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm my-0 mr-md-auto font-weight-normal">
      <h3>Свяжись с нами: </h3>
      <h4> Наш адрес: ул.Мельникайте, 42/2;</h4>
      <h4> Наши телефоны: +375 29 1922997, +375 25 1623456;</h4>
        <h4>Наша почта: yogahall@gmail.com;</h4>
        <h4>Наш инстаграмм: YogaHall_Minsk;</h4>


    </div>
  </div>


	<?php require "blocks/footer.php" ?>
 </body>
</html>
