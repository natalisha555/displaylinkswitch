<!DOCTYPE HTML >
<html lang="ru">
 <head>
  <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<meta http-equiv="X-UA-Compatible" content="ie=edge">

<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="dns-prefetch" href="//netdna.bootstrapcdn.com">

	<title> PHP web-site</title>
 </head>

<body style="background-image:url(img/fon.jpg); background-size:100%; height:800px;">

	<?php require "blocks/header.php" ?>

<?php

$krit1=filter_var(trim($_POST['type']),  FILTER_SANITIZE_STRING);

$krit2=filter_var(trim($_POST['type1']),  FILTER_SANITIZE_STRING);
$krit3=filter_var(trim($_POST['type2']),  FILTER_SANITIZE_STRING);

if($krit1=='' or $krit2=='' or $krit3=='')
{
  echo ' <h3 style="margin-left:150px"> Выберите все критерии!!! </h3>  ';
}
// cравнение по важности критериев, рейтинг критериев bac

$a=array();
$b=array();
$c=array();

$a[0]=1;
$a[1]=0.333;
$a[2]=5;

$b[0]=3;
$b[1]=1;
$b[2]=8;

$c[0]=1/5;
$c[1]=1/8;
$c[2]=1;

$c1=pow($a[0]*$a[1]*$a[2],1/3); //$krit2
$c2=pow($b[0]*$b[1]*$b[2],1/3); // $krit1
$c3=pow($c[0]*$c[1]*$c[2],1/3);// $krit3;



$c=$c1+$c2+$c3;

$L1=$c1/$c;
$L2=$c2/$c;
$L3=$c3/$c;




$servername = "localhost:3307";
$database = "yogahall";
$username = "root";
$password = "root";
// Создаем соединение

$conn = mysqli_connect($servername, $username, $password, $database);
// Проверяем соединение
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}


$result=$conn->query("SELECT  idteacher,proficiency, clientorint, communication from rates ");

$mass = array();
$i=0;
$j=0;

$n=mysqli_num_rows($result);

while($rws = mysqli_fetch_assoc($result)){
  $j=0;

   $mass[$i][$j] = $rws['idteacher'];

     $j++;
  $mass[$i][$j] = $rws['proficiency'];
   $j++;
  $mass[$i][$j] = $rws['clientorint'];
     $j++;
   $mass[$i][$j] = $rws['communication'];


   $i++;
}
//оценки $mass[$i][8];
//print_r( $mass[7][8] );

$result2=$conn->query("SELECT distinct idteacher from rates");
$i=0;
$teachers = array();
while($rws = mysqli_fetch_assoc($result2)){

  $teachers[$i] = $rws['idteacher'];

  $i++;

}
$count=$i;


// расчет первого критерия- профессионализм преподавтеля

$sum=array();

$cl=0;
for ($i=0;$i<$count;$i++)
{
  $cl=0;
for ($j=0;$j<$n;$j++){

//echo $mass[$j][0]; echo ' ';
//echo $teachers[$i]; echo '  ';
//echo 'sravn ';
  if(  $mass[$j][0]==$teachers[$i])
  {
    $sum[$i]+=$mass[$j][1];
    $cl++;
  //  echo 'sovpad ';
  }

}
//echo $teachers[$i]; echo ' ';
$sum[$i]=$sum[$i]/$cl;
//echo $sum[$i]; echo ' ';

}



$matrix=array();
$matr=array();

for($d=0;$d<$count;$d++){

  for($j=0;$j<$count;$j++){

$min=$sum[$d]-$sum[$j];

if($sum[$d]==$sum[$j]){
   $matrix[$j]=1;
 } elseif(($min>0) && ($min<=0.5) ){
   $matrix[$j]=2;
} elseif(($min>0.5) && ($min<=1) ){
  $matrix[$j]=3;
} elseif ( ($min>1) && ($min<=1.5) ){
  $matrix[$j]=4;
} elseif(($min>1.5) && ($min<=2) ){
  $matrix[$j]=5;
} elseif ( ($min>2) && ($min<=2.5) ){
  $matrix[$j]=6;
}elseif ( ($min>2.5) && ($min<=3) ){
  $matrix[$j]=7;
}elseif ( ($min>3) && ($min<=3.5) ){
  $matrix[$j]=8;
}elseif ( ($min>3.5) && ($min<=4) ){
  $matrix[$j]=9;
}elseif ( ($min>4) && ($min<=4.5) ){
  $matrix[$j]=10;
}elseif ( ($min>4.5) && ($min<=5) ){
  $matrix[$j]=11;
}elseif(($sum[$d]-$sum[$j]<0) && (($sum[$d]-$sum[$j])>=-0.5) ){
  $matrix[$j]=1/2;
}elseif(($sum[$d]-$sum[$j]<-0.5) && (($sum[$d]-$sum[$j])>=-1) ){
  $matrix[$j]=1/3;
} elseif ( ($sum[$d]-$sum[$j]<-1) && ($sum[$d]-$sum[$j]>=-1.5) ){
  $matrix[$j]=1/4;
} elseif(($sum[$d]-$sum[$j]<-1.5) && (($sum[$d]-$sum[$j])>=-2) ){
  $matrix[$j]=1/5;
} elseif ( ($sum[$d]-$sum[$j]<-2) && ($sum[$d]-$sum[$j]>=-2.5) ){
  $matrix[$j]=1/6;
}elseif ( ($sum[$d]-$sum[$j]<-2.5) && ($sum[$d]-$sum[$j]>=-3) ){
  $matrix[$j]=1/7;
}elseif ( ($sum[$d]-$sum[$j]<-3) && ($sum[$d]-$sum[$j]>=-3.5) ){
  $matrix[$j]=1/8;
}elseif ( ($sum[$d]-$sum[$j]<-3.5) && ($sum[$d]-$sum[$j]>=-4) ){
  $matrix[$j]=1/9;
}elseif ( ($sum[$d]-$sum[$j]<-4) && ($sum[$d]-$sum[$j]>=-4.5) ){
  $matrix[$j]=1/10;
}else {
  $matrix[$j]=1/11;
}



$matr[$d][]=round($matrix[$j],3);

  }


}

$geom=array();

for($i=0;$i<$count;$i++){
$mnoz=1;
for($j=0;$j<$count;$j++){
  $mnoz*=$matr[$i][$j];
}
$geom[$i]=round(pow($mnoz,1/$count),5);

}

$SUM=0;
for($k=0;$k<$count;$k++){
  $SUM+=$geom[$k];
}


$Lok_prof=array();
for($i=0;$i<$count;$i++){

$Lok_prof[$i]=$geom[$i]/$SUM;

}


//расчет второго критерия - клиентоориентированность


$sum=array();

$cl=0;
for ($i=0;$i<$count;$i++)
{
  $cl=0;
for ($j=0;$j<$n;$j++){

//echo $mass[$j][0]; echo ' ';
//echo $teachers[$i]; echo '  ';
//echo 'sravn ';
  if(  $mass[$j][0]==$teachers[$i])
  {
    $sum[$i]+=$mass[$j][2];
    $cl++;
  //  echo 'sovpad ';
  }

}
//echo $teachers[$i]; echo ' ';
$sum[$i]=$sum[$i]/$cl;
//echo $sum[$i]; echo ' ';

}

//echo ' ggggdosuda ';

$matrix=array();
$matr=array();

for($d=0;$d<$count;$d++){

  for($j=0;$j<$count;$j++){

$min=$sum[$d]-$sum[$j];

if($sum[$d]==$sum[$j]){
   $matrix[$j]=1;
 } elseif(($min>0) && ($min<=0.5) ){
   $matrix[$j]=2;
} elseif(($min>0.5) && ($min<=1) ){
  $matrix[$j]=3;
} elseif ( ($min>1) && ($min<=1.5) ){
  $matrix[$j]=4;
} elseif(($min>1.5) && ($min<=2) ){
  $matrix[$j]=5;
} elseif ( ($min>2) && ($min<=2.5) ){
  $matrix[$j]=6;
}elseif ( ($min>2.5) && ($min<=3) ){
  $matrix[$j]=7;
}elseif ( ($min>3) && ($min<=3.5) ){
  $matrix[$j]=8;
}elseif ( ($min>3.5) && ($min<=4) ){
  $matrix[$j]=9;
}elseif ( ($min>4) && ($min<=4.5) ){
  $matrix[$j]=10;
}elseif ( ($min>4.5) && ($min<=5) ){
  $matrix[$j]=11;
}elseif(($sum[$d]-$sum[$j]<0) && (($sum[$d]-$sum[$j])>=-0.5) ){
  $matrix[$j]=1/2;
}elseif(($sum[$d]-$sum[$j]<-0.5) && (($sum[$d]-$sum[$j])>=-1) ){
  $matrix[$j]=1/3;
} elseif ( ($sum[$d]-$sum[$j]<-1) && ($sum[$d]-$sum[$j]>=-1.5) ){
  $matrix[$j]=1/4;
} elseif(($sum[$d]-$sum[$j]<-1.5) && (($sum[$d]-$sum[$j])>=-2) ){
  $matrix[$j]=1/5;
} elseif ( ($sum[$d]-$sum[$j]<-2) && ($sum[$d]-$sum[$j]>=-2.5) ){
  $matrix[$j]=1/6;
}elseif ( ($sum[$d]-$sum[$j]<-2.5) && ($sum[$d]-$sum[$j]>=-3) ){
  $matrix[$j]=1/7;
}elseif ( ($sum[$d]-$sum[$j]<-3) && ($sum[$d]-$sum[$j]>=-3.5) ){
  $matrix[$j]=1/8;
}elseif ( ($sum[$d]-$sum[$j]<-3.5) && ($sum[$d]-$sum[$j]>=-4) ){
  $matrix[$j]=1/9;
}elseif ( ($sum[$d]-$sum[$j]<-4) && ($sum[$d]-$sum[$j]>=-4.5) ){
  $matrix[$j]=1/10;
}else {
  $matrix[$j]=1/11;
}



$matr[$d][]=round($matrix[$j],3);

//echo $matrix[$j]; echo ' ';

  }
//echo ' krug ';

}

$geom=array();

for($i=0;$i<$count;$i++){
$mnoz=1;
for($j=0;$j<$count;$j++){
  $mnoz*=$matr[$i][$j];
}
$geom[$i]=round(pow($mnoz,1/$count),5);
//echo $geom[$i]; echo ' ';
}

$SUM=0;
for($k=0;$k<$count;$k++){
  $SUM+=$geom[$k];
}

//echo $SUM;

$Lok_client=array();
for($i=0;$i<$count;$i++){

$Lok_client[$i]=$geom[$i]/$SUM;
//echo ' Lok2 ';
//echo $Lok_client[$i];
}



//расчет третьего критерия - коммуникация


$sum=array();

$cl=0;
for ($i=0;$i<$count;$i++)
{
  $cl=0;
for ($j=0;$j<$n;$j++){

//echo $mass[$j][0]; echo ' ';
//echo $teachers[$i]; echo '  ';
//echo 'sravn ';
  if(  $mass[$j][0]==$teachers[$i])
  {
    $sum[$i]+=$mass[$j][3];
    $cl++;
  //  echo 'sovpad ';
  }

}
//echo $teachers[$i]; echo ' ';
$sum[$i]=$sum[$i]/$cl;
//echo $sum[$i]; echo ' ';

}

//echo ' ggggdosuda ';

$matrix=array();
$matr=array();

for($d=0;$d<$count;$d++){

  for($j=0;$j<$count;$j++){

$min=$sum[$d]-$sum[$j];

if($sum[$d]==$sum[$j]){
   $matrix[$j]=1;
 } elseif(($min>0) && ($min<=0.5) ){
   $matrix[$j]=2;
} elseif(($min>0.5) && ($min<=1) ){
  $matrix[$j]=3;
} elseif ( ($min>1) && ($min<=1.5) ){
  $matrix[$j]=4;
} elseif(($min>1.5) && ($min<=2) ){
  $matrix[$j]=5;
} elseif ( ($min>2) && ($min<=2.5) ){
  $matrix[$j]=6;
}elseif ( ($min>2.5) && ($min<=3) ){
  $matrix[$j]=7;
}elseif ( ($min>3) && ($min<=3.5) ){
  $matrix[$j]=8;
}elseif ( ($min>3.5) && ($min<=4) ){
  $matrix[$j]=9;
}elseif ( ($min>4) && ($min<=4.5) ){
  $matrix[$j]=10;
}elseif ( ($min>4.5) && ($min<=5) ){
  $matrix[$j]=11;
}elseif(($sum[$d]-$sum[$j]<0) && (($sum[$d]-$sum[$j])>=-0.5) ){
  $matrix[$j]=1/2;
}elseif(($sum[$d]-$sum[$j]<-0.5) && (($sum[$d]-$sum[$j])>=-1) ){
  $matrix[$j]=1/3;
} elseif ( ($sum[$d]-$sum[$j]<-1) && ($sum[$d]-$sum[$j]>=-1.5) ){
  $matrix[$j]=1/4;
} elseif(($sum[$d]-$sum[$j]<-1.5) && (($sum[$d]-$sum[$j])>=-2) ){
  $matrix[$j]=1/5;
} elseif ( ($sum[$d]-$sum[$j]<-2) && ($sum[$d]-$sum[$j]>=-2.5) ){
  $matrix[$j]=1/6;
}elseif ( ($sum[$d]-$sum[$j]<-2.5) && ($sum[$d]-$sum[$j]>=-3) ){
  $matrix[$j]=1/7;
}elseif ( ($sum[$d]-$sum[$j]<-3) && ($sum[$d]-$sum[$j]>=-3.5) ){
  $matrix[$j]=1/8;
}elseif ( ($sum[$d]-$sum[$j]<-3.5) && ($sum[$d]-$sum[$j]>=-4) ){
  $matrix[$j]=1/9;
}elseif ( ($sum[$d]-$sum[$j]<-4) && ($sum[$d]-$sum[$j]>=-4.5) ){
  $matrix[$j]=1/10;
}else {
  $matrix[$j]=1/11;
}



$matr[$d][]=round($matrix[$j],3);

//echo $matrix[$j]; echo ' ';

  }
//echo ' krug ';

}

$geom=array();

for($i=0;$i<$count;$i++){
$mnoz=1;
for($j=0;$j<$count;$j++){
  $mnoz*=$matr[$i][$j];
}
$geom[$i]=round(pow($mnoz,1/$count),5);
//echo $geom[$i]; echo ' ';
}

$SUM=0;
for($k=0;$k<$count;$k++){
  $SUM+=$geom[$k];
}

//echo $SUM;

$Lok_commun=array();
for($i=0;$i<$count;$i++){

$Lok_commun[$i]=$geom[$i]/$SUM;
//echo ' Lok2 ';
//echo $Lok_client[$i];
}

$Glob=array();

if($krit1=='prof' && $krit2='comun'){
for($i=0;$i<$count;$i++){
$Glob[$i]=$Lok_prof[$i]*$L2+$Lok_commun[$i]*$L1+ $Lok_client[$i]*$L3;
//echo 'oololo';
} }

if($krit1=='comun' && $krit2='prof'){
for($i=0;$i<$count;$i++){
$Glob[$i]=$Lok_prof[$i]*$L1+$Lok_commun[$i]*$L2+ $Lok_client[$i]*$L3;
} }

if($krit1=='cly' && $krit2='prof'){
for($i=0;$i<$count;$i++){
$Glob[$i]=$Lok_prof[$i]*$L1+$Lok_commun[$i]*$L3+ $Lok_client[$i]*$L2;

} }

if($krit1=='prof' && $krit2='cly'){
for($i=0;$i<$count;$i++){
$Glob[$i]=$Lok_prof[$i]*$L2+$Lok_commun[$i]*$L3+ $Lok_client[$i]*$L1;
} }


if($krit1=='comun' && $krit2='cly'){
for($i=0;$i<$count;$i++){
$Glob[$i]=$Lok_prof[$i]*$L3+$Lok_commun[$i]*$L2+ $Lok_client[$i]*$L1;
} }


if($krit1=='cly' && $krit2='comun'){
for($i=0;$i<$count;$i++){
$Glob[$i]=$Lok_prof[$i]*$L3+$Lok_commun[$i]*$L1+ $Lok_client[$i]*$L2;
} }

for($i=0;$i<$count;$i++){
//echo $Glob[$i]; echo ' ';
}


$rating=array();
$rating=$Glob;
rsort($rating);

$number=array();

$result=array();

$rating=array_unique($rating);


for($i=0;$i<$count;$i++){

for($j=0;$j<$count;$j++){
//echo $wow[$i];
if($Glob[$j]==$rating[$i])
{

  $number[$i]=$teachers[$j];
 //echo $number[$i];echo' ';
}
}
}


// $number - массив результир с айди преподов по рейтингу для пользователя

// что делать с повторяющимися значениями? - меньше округлять
// засунуть часть кода в функции?
$datti=date('Y-m-d');


$result3=$conn-> query("SELECT idclass,fio, type_of_yoga ,date, time from
  classes inner join teachers on classes.idteacher=teachers.idteacher
  inner join types_of_yoga on classes.idtype=types_of_yoga.idtype where
   classes.idteacher in ('$number[0]', '$number[1]', '$number[2]','$number[3]')
   and classes.date>='$datti'");
$i=0;






 if($krit1=='' or $krit2=='' or $krit3=='')
 {
   echo ' <h3 style="margin-left:150px"> Выберите все критерии!!! </h3>  ';
 } else {?>
 <h3 style="text-align:center " > Мы вам предлагаем!</h3>
<?php }?>
      <div class="container mt-5">

      <div class="row row-cols-1 row-cols-md-3 mb-3 text-center">
         <?php  while($rws = mysqli_fetch_assoc($result3)) { $i++; ?>
        <div class="col">

          <div class="card mb-4 rounded-3 shadow-sm">
            <div class="card-header py-3">
              <h4 class="my-0 fw-normal"><?php  echo $rws['type_of_yoga']; ?></h4>
            </div>
            <div class="card-body">
            <img src="img/<?php  echo $i ?>.jpg" class="img-thumbnail" alt="">
              <h1 class="card-title pricing-card-title"><small class="text-muted fw-light"></small></h1>
              <ul class="list-unstyled mt-3 mb-4">
                <li><?php  echo "Преподаватель: "; echo $rws['fio'] ?></li>
                <li><?php  echo "Время: "; echo $rws['time'];  $idclass=$rws['idclass']?>           </li>
                <li><?php  echo "Дата: "; echo $rws['date']; ?></li>
                <li></li>
              </ul>
              <form action="che.php"  method="post">
   <input type="hidden"  name="idclass" value="<?php echo  $idclass?>"  ><br>




   <button type="submit" class="w-100 btn btn-lg btn-primary">Записаться </button>



   </form>
            </div>
          </div>
        </div>
   <?php } ?>
        </div>

      </div>






 <br> <br> <br><br> <br> <br>



 	<?php require "blocks/footer.php" ?>

 </body>
</html>
