<?php
$message = filter_var(trim($_POST['message']),
FILTER_SANITIZE_STRING);
$post = filter_var(trim($_POST['post']),
FILTER_SANITIZE_STRING);




$error='';
if(trim($post)=='')
$error='Введите отправителя';
else if (trim($message)=='')
$error='Введите само сообщение';
else if(strlen($message)<20)
$error='Cообщение должно быть больше 20 символов';


if($error!=''){
  echo $error;
  exit;
}


$servername = "localhost:3307";
$database = "yogahall";
$username = "root";
$password = "root";
// Создаем соединение

$conn = mysqli_connect($servername, $username, $password, $database);
// Проверяем соединение
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$i=0;

if($post=='s'){
$result=$conn->query("SELECT  email from teachers ");
echo 'olo';
}
elseif($post=='c'){
$result=$conn->query("SELECT  email from emails ");
}
else{

}
$i=0;
$n=0;
while($row=mysqli_fetch_array($result)){
  $mass[$i]= $row['email'];
  $i++;
  $n=$i;
}


for($i=0;$i<$n;$i++){
  $subject="=?utf-8?B?".base64_encode("Yogahall")."?=";
  $headers="From: director@mail.com\r\nReply-to: $mass[$i]\r\nContent-type:text/html;charset=utf-8\r\n";


  mail($mass[$i],$subject, $message, $headers);

}

header('Location: /director.php');


exit();




 ?>
