<?php

$servername = "localhost:3307";
$database = "yogahall";
$username = "root";
$password = "root";
// Создаем соединение

$conn = mysqli_connect($servername, $username, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}



$date=date('Y-m-d');

$result=$conn->query("SELECT idclass,fio, type_of_yoga ,date, time from
classes inner join teachers on classes.idteacher=teachers.idteacher
inner join types_of_yoga on classes.idtype=types_of_yoga.idtype
where date>='$date' ");

$classes = array();

// Сохраняем записи таблицы в массив
while( $row = $result->fetch_assoc() ) {
$classes[] = $row;

}

// Проверяем, нажата ли кнопка экспорта
if(isset($_POST["export"])) {
// Определим имя файла с текущей датой
$fileName = "Расписание классов-".date('d-m-Y').".xls";

// Устанавливаем информацию заголовка для экспорта данных в формате Excel
header('Content-Type: application/vnd.ms-excel; charset=utf-8');
header('Content-Disposition: attachment; filename='.$fileName);


// Устанавливаем переменную в false для заголовка
$heading = false;

// Добавляем данные таблицы MySQL в файл Excel

if(!empty($classes)) {
foreach($classes as $class) {
if(!$heading) {
echo implode("\t", array_keys($class)) . "\n";
$heading = true;
}
echo implode("\t", array_values($class)) . "\n";
}
}
exit();
}




?>
