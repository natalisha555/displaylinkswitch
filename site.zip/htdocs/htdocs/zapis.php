<?php
// Добавить скрипт для чтения данных MySQL и экспорта в Excel
include "read_and_export.php";
?>
<!DOCTYPE HTML >
<html lang="ru">
 <head>
  <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<meta http-equiv="X-UA-Compatible" content="ie=edge">

<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="dns-prefetch" href="//netdna.bootstrapcdn.com">

	<title> PHP web-site</title>
 </head>

<body style="background-image:url(img/fon.jpg); background-size:100%; height:800px;">

	<?php require "blocks/header.php";?>

  <div class="container mt-4 stil">

    <h1 class="col1">Запись на занятие</h1>

  <a class="col1">  Наши классы сегодня</a>
  <a class="col1 font">
<?php echo date('d-m-Y');
 $dat=date('Y-m-d');?></a>

 <div class="container">
 <br>
 <div class="col-sm-12">
 <div>
 <form action="#" method="post" class="color">
 <button type="submit" id="export" name="export"
 value="Export to excel" class="btn color btn-success">Экспорт расписания в Excel</button>
 </form>
 </div>
 </div>
 <br/>
 <table  id="" class="table hidde table-striped table-bordered">
 <tr>
 <th>Занятие</th>
 <th>Преподаватель</th>
 <th>Вид йоги</th>
 <th>Дата</th>
 <th>Время</th>
 </tr>
 <tbody>
 <?php foreach($classes as $class) { ?>
 <tr>
 <td><?php echo $class ['idclass']; ?></td>
 <td><?php echo $class ['fio']; ?></td>
 <td><?php echo $class ['idtype']; ?></td>
 <td><?php echo $class ['date']; ?></td>
 <td>$<?php echo $class ['time']; ?></td>
 </tr>
 <?php } ?>
 </tbody>
 </table>

 </div>


<form action="zapis2.php" method="post">
  <input type="hidden" class="form-control" name="dat" id="dat" value="<?php echo $dat;?>" >
  <button   type="submit" class="btn col222 btn-success">Показать классы следующего дня</button>
</form>



<?php
$servername = "localhost:3307";
$database = "yogahall";
$username = "root";
$password = "root";
// Создаем соединение

$conn = mysqli_connect($servername, $username, $password, $database);
// Проверяем соединение
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$result=$conn -> query("SELECT idclass,fio, type_of_yoga ,date, time from
  classes inner join teachers on classes.idteacher=teachers.idteacher
  inner join types_of_yoga on classes.idtype=types_of_yoga.idtype where
  date='$dat' ");



$class=$result->fetch_all();



   ?>



   <div class="container mt-5">

   <div class="row row-cols-1 row-cols-md-3 mb-3 text-center">
      <?php foreach($class as $cl): ?>
     <div class="col">

       <div class="card mb-4 rounded-3 shadow-sm">
         <div class="card-header py-3">
           <h4 class="my-0 fw-normal"><?php echo $cl[2] ?></h4>
         </div>
         <div class="card-body">
         <img src="img/<?php $i++; echo $i; ?>.jpg" class="img-thumbnail" alt="">
           <h1 class="card-title pricing-card-title"><small class="text-muted fw-light"></small></h1>
           <ul class="list-unstyled mt-3 mb-4">
             <li><?php  echo "Преподаватель: "; echo $cl[1] ?></li>
             <li><?php  echo "Время: "; echo $cl[4]; $idclass=$cl[0]?>           </li>
             <li></li>
             <li></li>
           </ul>
           <form action="che.php"  method="post">
<input type="hidden"  name="idclass" value="<?php echo  $idclass?>"  ><br>

<?php

$result22=$conn -> query( "SELECT count(idnote) from note inner join classes
 on note.idclass=classes.idclass  where date='$dat' and classes.idclass='$idclass' ");



 if(mysqli_num_rows($result22)>10):
 ?>

  <button type="" class="w-100 btn btn-danger btn-primary" disabled>Запись закрыта</button>

<?php else: ?>


<button type="submit" class="w-100 btn btn-lg btn-primary">Записаться </button>

<?php endif ?>

</form>
         </div>
       </div>
     </div>
<?php endforeach ?>
     </div>

   </div>









 <br> <br> <br>




    </div>

    <style>
    .hidde{
      display:none;
    }
    .stil{
      text-align: center;
      padding-top: 0px;
    }
    .sdvig{
      padding-left:300px;
    }
    .col222{
      color:yellow;
    }
    .col1{
      color:yellow;

    }
    .font{
      font-size:15pt;
    }
    .color{
      color:purple;
        padding-left:10px;
    }

    </style>

    <br> <br> <br><br> <br> <br>
<br> <br> <br><br> <br> <br>

 	<?php require "blocks/footer.php" ?>

 </body>
</html>
