<!DOCTYPE HTML >
<html lang="ru">
 <head>
  <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<meta http-equiv="X-UA-Compatible" content="ie=edge">

<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="dns-prefetch" href="//netdna.bootstrapcdn.com">
	<title> PHP web-site</title>


 </head>
 <body style="background-image:url(img/back.jpg); background-size:100%" >

	<?php require "blocks/header.php" ?>
<div>
    <h3 align="center">Наши цены</h3>
    <div class="container" id="page">
  		<div class="container-inner">
  			<div class="main">
  				<div class="main-inner group">
  <section class="content">

  	<div class="page-title pad group">



  </div><!--/.page-title-->
  	<div class="pad group">


  			<article class="group post-14 page type-page status-publish hentry">


  				<div >


  <p>Абонементы в йога-студии Ом действуют в течение одного месяца с момента активации.
     Оплата разового занятия не гарантирует наличие свободного места в группе.
      При отсутствии абонемента, пожалуйста, регистрируйтесь на разовые занятия по телефону.</p>
  <table style="height: 48px;" width="100%">
  <tbody>


    </tr>
    </tbody>
    </table>
    <h5 style="text-align: center";>Разовые занятия</h5>
  <p style="text-align: center";>Разовое занятие 1,5 часа -<strong> 20 BYN</strong></p>

  </tr>

  <p style="text-align: center";>Разовое занятие Термо йога -<strong> 22 BYN</strong></p>
    <br>

  </tr>
  </tbody>
  </table>


<table style="height: 48px;" width="100%">
<tbody>


  </tr>
  </tbody>
  </table>
  <h5 style="text-align: center"; >Абонементы</h5>

<p style="text-align: center";>Стандартный-<strong> 135 BYN</strong></p>
<p style="text-align: center";>Включает 10 занятий в течение 30 дней</p>

  <p style="text-align: center";>Индивидуальное разовое занятие для двоих - <strong> 50 BYN </strong></p>
    <br>  <br>
  </tr>
  </tbody>
  </table>
  <p style="text-align: left;">Если вы не нашли интересующий вас абонемент или вы хотите приобрести подарочную карту, пожалуйста свяжитесь с нами. Здесь представлены цены на наиболее ходовые абонементы. Стоимость занятий йогой может зависеть от количества занятий в абонементе.</p>
  <p style="text-align: justify;"><a name="adjna"></a></p>

  				</div><!--/.main-inner-->
  			</div><!--/.main-->
  		</div><!--/.container-inner-->


</div>
	<?php require "blocks/footer.php" ?>
 </body>
</html>
