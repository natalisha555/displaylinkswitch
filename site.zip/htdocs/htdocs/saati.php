<!DOCTYPE HTML >
<html lang="ru">
 <head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">

   <meta http-equiv="X-UA-Compatible" content="ie=edge">

 <link rel="stylesheet" href="css/style.css">
 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
 <link rel="dns-prefetch" href="//netdna.bootstrapcdn.com">
<style>
body{
  background: #338;
}
h3{
  color:green;
}
</style>
   <title> PHP web-site</title>
 </head>
 <body bgcolor="navy">

   	<?php require "blocks/header.php" ?>

<?php

$servername = "localhost:3307";
$database = "yogahall";
$username = "root";
$password = "root";
// Создаем соединение

$conn = mysqli_connect($servername, $username, $password, $database);
// Проверяем соединение
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}


$result=$conn->query("SELECT iduser, idteacher,proficiency, clientorint, communication, imp1, imp2,imp3 from rates ");

$mass = array();
$i=0;
$j=0;

$n=mysqli_num_rows($result);

while($rws = mysqli_fetch_assoc($result)){
  $j=0;
  $mass[$i][$j] = $rws['iduser'];
  $j++;
   $mass[$i][$j] = $rws['idteacher'];

     $j++;
  $mass[$i][$j] = $rws['proficiency'];
   $j++;
  $mass[$i][$j] = $rws['clientorint'];
     $j++;
   $mass[$i][$j] = $rws['communication'];
     $j++;
     $mass[$i][$j] = $rws['imp1'];
       $j++;
       $mass[$i][$j] = $rws['imp2'];
       $j++;
       $mass[$i][$j] = $rws['imp3'];
$j++;
 $mass[$i][$j] = $rws['proficiency']*$rws['imp1']+$rws['clientorint']*$rws['imp2']+$rws['communication']*$rws['imp3'];

   $i++;
}
//оценки $mass[$i][8];
//print_r( $mass[7][8] );

$result2=$conn->query("SELECT distinct idteacher from rates");
$i=0;
$teachers = array();
while($rws = mysqli_fetch_assoc($result2)){

  $teachers[$i] = $rws['idteacher'];
  $i++;

}
$count=$i;
$sum=array();

$i=0;
$cl=0;
for ($i=0;$i<$count;$i++)
{
  $cl=0;
for ($j=0;$j<$n;$j++){

  if(  $mass[$j][1]==$teachers[$i])
  {
    $sum[$i]+=$mass[$j][8];
    $cl++;
  }

}

$sum[$i]/=$cl;

}

$SUM=0;
$i=0;
while($sum[$i])
{
  $SUM+=$sum[$i];
  $i++;
}


$ves=array();

for($l=0;$l<$count;$l++){
  $ves[$l]=round($sum[$l]/$SUM,5,);

}




$wow=array();
$wow=$ves;
rsort($wow);
$number=array();

for($i=0;$i<$count;$i++){

for($j=0;$j<$count;$j++){

//echo $wow[$i];
if($sum[$j]==round($wow[$i]*$SUM,0, PHP_ROUND_HALF_UP))
{
  $number[$i]=$teachers[$j];
}

}

}



$result3=$conn-> query("SELECT idclass,fio, type_of_yoga ,date, time from
  classes inner join teachers on classes.idteacher=teachers.idteacher
  inner join types_of_yoga on classes.idtype=types_of_yoga.idtype where
   classes.idteacher in ('$number[0]', '$number[1]', '$number[2]') ");




$i=0;




 ?>

<h3 style="text-align:center " > Мы вам предлагаем!</h3>
     <div class="container mt-5">

     <div class="row row-cols-1 row-cols-md-3 mb-3 text-center">
        <?php  while($rws = mysqli_fetch_assoc($result3)) { $i++; ?>
       <div class="col">

         <div class="card mb-4 rounded-3 shadow-sm">
           <div class="card-header py-3">
             <h4 class="my-0 fw-normal"><?php  echo $rws['type_of_yoga']; ?></h4>
           </div>
           <div class="card-body">
           <img src="img/<?php  echo $i ?>.jpg" class="img-thumbnail" alt="">
             <h1 class="card-title pricing-card-title"><small class="text-muted fw-light"></small></h1>
             <ul class="list-unstyled mt-3 mb-4">
               <li><?php  echo "Преподаватель: "; echo $rws['fio'] ?></li>
               <li><?php  echo "Время: "; echo $rws['time']; $idclass=$rws['idclass']?>           </li>
               <li></li>
               <li></li>
             </ul>
             <form action="che.php"  method="post">
  <input type="hidden"  name="idclass" value="<?php echo  $idclass?>"  ><br>




  <button type="submit" class="w-100 btn btn-lg btn-primary">Записаться </button>



  </form>
           </div>
         </div>
       </div>
  <?php } ?>
       </div>

     </div>




<br> <br> <br> <br> <br>

     	<?php require "blocks/footer.php" ?>

     </body>
    </html>
