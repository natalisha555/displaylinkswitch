<!DOCTYPE HTML >
<html lang="ru">
 <head>

  <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">

<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="dns-prefetch" href="//netdna.bootstrapcdn.com">

<title> PHP web-site</title>

<style type="text/css">
BODY {
background: url(img/1.jpg) no-repeat  20px; /* Параметры фона */
}
</style>


 </head>
 <body>


	<?php require "blocks/header.php" ?>

  <div class="container mt-4">

    <h1>Добавление классов</h1>

    <form action="validation-form.php/checkadding.php" method="post">

<br><br>
      <select  name="type">
  <option selected>Выберите направление</option>
<option value="хатха">Хатха-йога</option>
<option value="виньяса">Виньяса-флоу</option>
<option value="нидра">Йога-нидра</option>
<option value="аштанга">Аштанга</option>
</select> <br> <br>

<input type="text" class="form-control" name="teacher" id="teacher" placeholder="Введите преподавателя " ><br>

<input type="time" class="form-control" name="time" id="time" placeholder="Введите время занятия " ><br>

<input type="date" class="form-control" name="date" id="date" placeholder="Введите дату занятия " ><br>



<button   type="submit" class="btn btn-success">Добавить</button>
  </form>


    </div>
<br> <br> <br>

 	<?php require "blocks/footer.php" ?>

 </body>
</html>
