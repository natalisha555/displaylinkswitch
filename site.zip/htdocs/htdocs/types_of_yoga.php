<!DOCTYPE HTML >
<html lang="ru">
 <head>
  <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<meta http-equiv="X-UA-Compatible" content="ie=edge">

<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="dns-prefetch" href="//netdna.bootstrapcdn.com">

	<title> PHP web-site</title>
 </head>
 <body>

	<?php require "blocks/header.php" ?>
  <div class="container mt-5">
    <h4 class="list-unstyled mt-3 mb-4 my-0 fw-normal">Выберите то, что вам подходит!</h4>

  <div class="row row-cols-1 row-cols-md-3 mb-3 text-center">
    <div class="col">
      <div class="card mb-4 rounded-3 shadow-sm">
        <div class="card-header py-3">
          <h4 class="my-0 fw-normal">Хатха-йога</h4>
        </div>
        <div class="card-body">
            <img src="img/6.jpg" class="img-thumbnail" alt="">
          <h1 class="card-title pricing-card-title"><small class="text-muted fw-light"></small></h1>
          <ul class="list-unstyled mt-3 mb-4">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
          </ul>
          <button type="button" class="w-100 btn btn-lg btn-primary">О направлении</button>
        </div>
      </div>
    </div>

    <div class="col">
        <div class="card mb-4 rounded-3 shadow-sm">
          <div class="card-header py-3">
            <h4 class="my-0 fw-normal">Виньяса-флоу</h4>
          </div>
          <div class="card-body">
            <img src="img/1.jpg" class="img-thumbnail" alt="">
            <h1 class="card-title pricing-card-title"><small class="text-muted fw-light"></small></h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li></li>
              <li></li>
              <li></li>
              <li></li>
            </ul>
            <button type="button" class="w-100 btn btn-lg btn-primary">О направлении</button>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card mb-4 rounded-3 shadow-sm">
          <div class="card-header py-3">
            <h4 class="my-0 fw-normal">Йога-нидра</h4>
          </div>
          <div class="card-body">
              <img src="img/2.jpg" class="img-thumbnail" alt="">
            <h1 class="card-title pricing-card-title"><small class="text-muted fw-light"></small></h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li></li>
              <li></li>
              <li></li>
              <li></li>
            </ul>
            <button type="button" class="w-100 btn btn-lg btn-primary">О направлении</button>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card mb-4 rounded-3 shadow-sm">
          <div class="card-header py-3">
            <h4 class="my-0 fw-normal">Йога в гамаках</h4>
          </div>
          <div class="card-body">
              <img src="img/3.jpg" class="img-thumbnail" alt="">
            <h1 class="card-title pricing-card-title"><small class="text-muted fw-light"></small></h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li></li>
              <li></li>
              <li></li>
              <li></li>
            </ul>
            <button type="button" class="w-100 btn btn-lg btn-primary">О направлении</button>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card mb-4 rounded-3 shadow-sm">
          <div class="card-header py-3">
            <h4 class="my-0 fw-normal">Аштанга</h4>
          </div>
          <div class="card-body">
              <img src="img/4.jpg" class="img-thumbnail" alt="">
            <h1 class="card-title pricing-card-title"><small class="text-muted fw-light"></small></h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li></li>
              <li></li>
              <li></li>
              <li></li>
            </ul>
            <button type="button" class="w-100 btn btn-lg btn-primary">О направлении</button>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card mb-4 rounded-3 shadow-sm">
          <div class="card-header py-3">
            <h4 class="my-0 fw-normal">Йога Айенгара</h4>
          </div>
          <div class="card-body">
              <img src="img/5.jpg" class="img-thumbnail" alt="">
            <h1 class="card-title pricing-card-title"><small class="text-muted fw-light"></small></h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li></li>
              <li></li>
              <li></li>
              <li></li>
            </ul>
            <button type="button" class="w-100 btn btn-lg btn-primary">О направлении</button>
          </div>
        </div>
      </div>


    </div>
  </div>


 	<?php require "blocks/footer.php" ?>

 </body>
</html>
