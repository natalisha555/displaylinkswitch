<!DOCTYPE HTML >
<html lang="ru">
 <head>
  <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<meta http-equiv="X-UA-Compatible" content="ie=edge">

<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="dns-prefetch" href="//netdna.bootstrapcdn.com">

	<title> PHP web-site</title>
 </head>
 <body>
   <?php require "blocks/header.php" ;

   $day = filter_var(trim($_POST['day']),
   FILTER_SANITIZE_STRING);?>

<h3 style="text-align:center" >Наши классы в <?php echo $day   ?></h3>
	<?php



$mysql= new mysqli('localhost:3307','root','root','yogahall');

$result=$mysql -> query("SELECT `idclass`,`fio`, `type_of_yoga` ,`day`, `time` from
  `classes` inner join `teachers` on classes.idteacher=teachers.idteacher
  inner join `types_of_yoga` on classes.idtype=types_of_yoga.idtype where
   `day`='$day' ");



$class=$result->fetch_all();



   ?>



   <div class="container mt-5">

   <div class="row row-cols-1 row-cols-md-3 mb-3 text-center">
      <?php foreach($class as $cl): ?>
     <div class="col">

       <div class="card mb-4 rounded-3 shadow-sm">
         <div class="card-header py-3">
           <h4 class="my-0 fw-normal"><?php echo $cl[2] ?></h4>
         </div>
         <div class="card-body">
         <img src="img/<?php $i++; echo $i; ?>.jpg" class="img-thumbnail" alt="">
           <h1 class="card-title pricing-card-title"><small class="text-muted fw-light"></small></h1>
           <ul class="list-unstyled mt-3 mb-4">
             <li><?php  echo "Преподаватель: "; echo $cl[1] ?></li>
             <li><?php  echo "Время: "; echo $cl[4]; $idclass=$cl[0]?>           </li>
             <li></li>
             <li></li>
           </ul>
           <form action="che.php"  method="post">
<input type="hidden"  name="idclass" value="<?php echo  $idclass?>"  ><br>

<?php

$result22=$mysql -> query( "SELECT count(`idnote`) as idnote  from `note` inner join `classes`
 on note.idclass=classes.idclass  where `day`='$day' and classes.idclass='$idclass' ");

$rez=$result22->fetch_assoc();

 if($rez['idnote']>10):
 ?>

  <button type="" class="w-100 btn btn-danger btn-primary" disabled>Запись закрыта</button>

<?php else: ?>


<button type="submit" class="w-100 btn btn-lg btn-primary">Записаться </button>

<?php endif ?>

</form>
         </div>
       </div>
     </div>
<?php endforeach ?>
     </div>

   </div>







 	<?php require "blocks/footer.php" ?>

 </body>
</html>
