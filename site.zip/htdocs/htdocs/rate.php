
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <title>Рейтинг: Фокусный</title>
    <style>
        body {
            margin: 0;
            padding: 25px;
            font-family: sans-serif;
        }

        /* Rating */

        .rating {
            margin: 0 0 1em 0;
            padding: 0;
            border: none;
        }

        /* Caption */

        .rating__caption {
            margin-bottom: 0.5em;
            padding: 0;
        }

        /* Group */

        .rating__group {
            position: relative;
            width: 10em;
            height: 2em;
            background-image: url(img/off.svg);
            background-size: 2em auto;
            background-repeat: repeat-x;
        }

        /* Star */

        .rating__star {
            position: absolute;
            top: 0;
            left: 0;
            margin: 0;
            height: 2em;
            font-size: inherit;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            background-size: 2em auto;
            background-repeat: repeat-x;
        }

        .rating__star:focus {
            outline: none;
        }

        .rating__star:focus ~ .rating__focus {
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            z-index: -1;
            outline: 0.2em solid #4a90e2;
            outline-offset: 0.2em;
        }

        .rating__star:hover,
        .rating__star:checked {
            background-image: url(img/on.svg);
        }

        .rating__star:hover ~ .rating__star {
            background-image: url(img/off.svg);
        }

        /* Options */

        .rating__star:nth-of-type(1) {
            z-index: 5;
            width: 2em;
        }

        .rating__star:nth-of-type(2) {
            z-index: 4;
            width: 4em;
        }

        .rating__star:nth-of-type(3) {
            z-index: 3;
            width: 6em;
        }

        .rating__star:nth-of-type(4) {
            z-index: 2;
            width: 8em;
        }

        .rating__star:nth-of-type(5) {
            z-index: 1;
            width: 10em;
        }
        .slidecontainer {
    width: 100%; /* Width of the outside container */
}

/* The slider itself */
.slider {
    -webkit-appearance: none;  /* Override default CSS styles */
    appearance: none;
    width: 150px; /* Full-width */
    height: 25px; /* Specified height */
    background: #d3d3d3; /* Grey background */
    outline: none; /* Remove outline */
    opacity: 0.7; /* Set transparency (for mouse-over effects on hover) */
    -webkit-transition: .2s; /* 0.2 seconds transition on hover */
    transition: opacity .2s;
}

/* Mouse-over effects */
.slider:hover {
    opacity: 1; /* Fully shown on mouse-over */
}

/* The slider handle (use -webkit- (Chrome, Opera, Safari, Edge) and -moz- (Firefox) to override default look) */
.slider::-webkit-slider-thumb {
    -webkit-appearance: none; /* Override default look */
    appearance: none;
    width: 25px; /* Set a specific slider handle width */
    height: 25px; /* Slider handle height */
    background: #4CAF50; /* Green background */
    cursor: pointer; /* Cursor on hover */
}

.slider::-moz-range-thumb {
    width: 25px; /* Set a specific slider handle width */
    height: 25px; /* Slider handle height */
    background: #4CAF50; /* Green background */
    cursor: pointer; /* Cursor on hover */
}
.bt{
  display: inline-block;
    color: black;
    font-size: 125%;
    font-weight: 700;
    text-decoration: none;
    user-select: none;
    padding: .25em .5em;
    outline: none;
    border: 1px solid rgb(250,172,17);
    border-radius: 7px;
    background: rgb(255,212,3) linear-gradient(rgb(255,212,3), rgb(248,157,23));
    box-shadow: inset 0 -2px 1px rgba(0,0,0,0), inset 0 1px 2px rgba(0,0,0,0), inset 0 0 0 60px rgba(255,255,0,0);
    transition: box-shadow .2s, border-color .2s;
}
.m{
  color: blue;
}

    </style>




</head>
<body>
  <?php

  $teach= filter_var(trim($_POST['teach']),  FILTER_SANITIZE_STRING);

?>
  <form action="addtodb.php" method="post" >
    <fieldset class="rating">
      <h4>  <legend class="rating__caption">Оцените профессионализм преподавателя!</legend></h4>
        <div class="rating__group">
            <input class="rating__star" type="radio" name="health" value="1" aria-label="Ужасно" >
            <input class="rating__star" type="radio" name="health" value="2" aria-label="Сносно">
            <input class="rating__star" type="radio" name="health" value="3" aria-label="Нормально">
            <input class="rating__star" type="radio" name="health" value="4" aria-label="Хорошо">
            <input class="rating__star" type="radio" name="health" value="5" aria-label="Отлично">
            <div class="rating__focus"></div>
        </div>
    </fieldset>
      <a>  <legend class="m">оцените важность профессионализма преподавателя для вас</legend></a>
    <select  name="imp1">
      <option selected>профессионализм</option>
    <option value="1">1</option>
    <option value="2">2</option>
    <option value="3">3</option>
    <option value="4">4</option>
    <option value="5">5</option>
    <option value="6">6</option>
      <option value="7">7</option>
        <option value="8">8</option>
          <option value="9">9</option>
            <option value="10">10</option>
    </select> <br>
    <fieldset class="rating">
      <h4>  <legend class="rating__caption">Оцените клиентоориентированность преподавателя</legend></h4>
        <div class="rating__group">
            <input class="rating__star" type="radio" name="mood" value="1" aria-label="Ужасно">
            <input class="rating__star" type="radio" name="mood" value="2" aria-label="Сносно">
            <input class="rating__star" type="radio" name="mood" value="3" aria-label="Нормально" >
            <input class="rating__star" type="radio" name="mood" value="4" aria-label="Хорошо">
            <input class="rating__star" type="radio" name="mood" value="5" aria-label="Отлично">
            <div class="rating__focus"></div>
        </div>
    </fieldset>
    <a>  <legend class="m">оцените важность клиентоориентированность преподавателя для вас</legend></a>
  <select  name="imp2">
    <option selected>клиентоориентированность</option>
  <option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
  <option value="6">6</option>
    <option value="7">7</option>
      <option value="8">8</option>
        <option value="9">9</option>
          <option value="10">10</option>
  </select> <br>
    <fieldset class="rating">
        <h4> <legend class="rating__caption">Оцените навыки коммуникации преподавателя</legend></h4>
        <div class="rating__group">
            <input class="rating__star" type="radio" name="general" value="1" aria-label="Ужасно">
            <input class="rating__star" type="radio" name="general" value="2" aria-label="Сносно">
            <input class="rating__star" type="radio" name="general" value="3" aria-label="Нормально">
            <input class="rating__star" type="radio" name="general" value="4" aria-label="Хорошо">
            <input class="rating__star" type="radio" name="general" value="5" aria-label="Отлично" >
            <div class="rating__focus"></div>
            <br>
            <br>


        </div>
    </fieldset>
    <a>  <legend class="m">оцените важность навыков коммуникации преподавателя для вас</legend></a>
    <select  name="imp3">
    <option selected>навык коммуникации</option>
    <option value="1">1</option>
    <option value="2">2</option>
    <option value="3">3</option>
    <option value="4">4</option>
    <option value="5">5</option>
    <option value="6">6</option>
    <option value="7">7</option>
      <option value="8">8</option>
        <option value="9">9</option>
          <option value="10">10</option>
    </select> <br>
     <input type="hidden" class="form-control" name="teach" id="teach" value="<?php echo $teach?>" >
     <br>

     <p>
     <h4> Для вас важнее профессионализм преподавтеля </p>
     <p> Или его клиентоориентированность? </p></h4>
     <div class="slidecontainer">
       <a> профи</a>
       <input type="range" min="1" max="100" value="50" class="slider" id="myRange">
       <a> клиент</a>
     </div>

     <input type="range" step="5" min="0" max="35" list="rangeList" onchange="document.getElementById('rangeValue').innerHTML = this.value;">
    <datalist id="rangeList">
    <option value="0" label="0">
<option value="5" label="5">
<option value="10" label="10">
  <option value="15" label="10">
    <option value="20" label="10">
      <option value="25" label="10">
        <option value="30" label="10">
          <option value="35" label="10">
</datalist>
<span id="rangeValue">5</span>


     <br>

    <button  class="bt" type="submit" >Готово!</button>
  </form>
<pre id="log">
</pre>

</body>
</html>
