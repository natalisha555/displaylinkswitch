<?php
session_start();

$login = filter_var(trim($_POST['login']),
FILTER_SANITIZE_STRING);

$pass = filter_var(trim($_POST['pass']),
FILTER_SANITIZE_STRING);


$pass=md5($pass."gfjkfd!124&");

$servername = "localhost:3307";
$database = "yogahall";
$username = "root";
$password = "root";
// Создаем соединение

$conn = mysqli_connect($servername, $username, $password, $database);
// Проверяем соединение
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$res=$conn -> query("SELECT * FROM users WHERE login='$login'
AND pass='$pass'");


$user=$res->fetch_assoc();
//echo $result;

if(count($user)==0){
 echo "Такого пользователя нет";
exit();
}

$_SESSION['message']=$user['name'];

mysqli_close($conn);


header('Location:/');


?>
