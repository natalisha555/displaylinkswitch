<?php
$date = filter_var(trim($_POST['date']),
FILTER_SANITIZE_STRING);
$type = filter_var(trim($_POST['type']),
FILTER_SANITIZE_STRING);
$teacher = filter_var(trim($_POST['teacher']),
FILTER_SANITIZE_STRING);
$time = filter_var(trim($_POST['time']),
FILTER_SANITIZE_STRING);

$servername = "localhost:3307";
$database = "yogahall";
$username = "root";
$password = "root";
// Создаем соединение

$conn = mysqli_connect($servername, $username, $password, $database);
// Проверяем соединение
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}




$typecheck=$conn->query("SELECT idtype FROM types_of_yoga  where type_of_yoga='$type' ");
if(!$typecheck) echo $conn->error;
//$user=$typecheck->fetch_assoc();

if(mysqli_num_rows ($typecheck)==0){
   $conn->query("insert into types_of_yoga(type_of_yoga) values ('$type')");

    $idtype=$conn->query("SELECT idtype FROM types_of_yoga
        where type_of_yoga='$type' ");
        $idty=$idtype->fetch_assoc();
        $idtype=$idty['idtype'];
}else {
$idtype=$conn->query("SELECT idtype FROM types_of_yoga
    where type_of_yoga='$type' ");
    $idty=$idtype->fetch_assoc();
    $idtype=$idty['idtype'];
}


$teachcheck=$conn->query("SELECT idteacher FROM teachers   where fio='$teacher' ");
if(!$teachcheck) echo $conn->error;
if(mysqli_num_rows($teachcheck)==0){
$conn->query("insert into teachers(fio) values ('$teacher')");
  $idteach=$conn->query("SELECT idteacher FROM teachers
     where fio='$teacher' ");
     $idte=$idteach->fetch_assoc();
     $idteach=$idte['idteacher'];
}else{
  $idteach=$conn->query("SELECT idteacher FROM teachers
     where fio='$teacher' ");
     $idte=$idteach->fetch_assoc();
     $idteach=$idte['idteacher'];
}



 $conn->query("INSERT INTO classes (date,idtype,idteacher,time)
  VALUES ('$date','$idtype','$idteach','$time')");



mysqli_close($conn);


header('Location:/admin_tool.php');







?>
