<!DOCTYPE HTML >
<html lang="ru">
 <head>
  <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<meta http-equiv="X-UA-Compatible" content="ie=edge">

<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="dns-prefetch" href="//netdna.bootstrapcdn.com">

<style type="text/css">
#rating {
    width: 320px;
    border-radius: 4px;
    box-shadow: 0 0 2px 1px #333333;
    margin: 10px auto;
    padding: 10px;
    text-align: center;
}
#rating div { float: left; }
#rating p { margin: 0; padding: 0; }
.param {
    width: 110px;
    margin: 0 20px 0 0;
    text-align: right;
}
.param, .rating, #summ { line-height: 28px; }
.stars, #sum_stars { background: url(image/stars.png); }
.stars, #sum_stars, .progress, #sum_progress {
    width: 130px;
    height: 28px;
    cursor: pointer;
}
.progress { background: #FFEE00; }
#sum_progress { background: #00EE00; }
.rating, #summ {
    margin: 0 0 0 20px;
    font-weight: bold;
}
</style>

</style>

	<title> PHP web-site</title>
 </head>
 <body>

	<?php require "blocks/header.php" ?>
  <div class="container mt-5">
    <h4 class="list-unstyled mt-3 mb-4 my-0 fw-normal">Наши преподаватели!</h4>

  <div class="row row-cols-1 row-cols-md-3 mb-3 text-center">
    <div class="col">
      <div class="card mb-4 rounded-3 shadow-sm">
        <div class="card-header py-3">
          <h4 class="my-0 fw-normal">Андрей Баладьев</h4>
          <h4 class="my-0 fw-normal"> Направление: хатха </h4>
        </div>
        <div class="card-body">
            <img src="img/6.jpg" class="img-thumbnail" alt="">
          <h1 class="card-title pricing-card-title"><small class="text-muted fw-light"></small></h1>
          <ul class="list-unstyled mt-3 mb-4">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
          </ul>

            <form action="rate.php" method="post">
             <input type="hidden" class="form-control" name="teach" id="teach" value="5" >
             <button   type="submit" class="btn col222 btn-success">Оценить преподавателя</button>
            </form>

          </form>

        </div>
      </div>
    </div>

    <div class="col">
        <div class="card mb-4 rounded-3 shadow-sm">
          <div class="card-header py-3">
              <h4 class="my-0 fw-normal">Лариса Монич</h4>
            <h4 class="my-0 fw-normal">Направление:виньяса</h4>
          </div>
          <div class="card-body">
            <img src="img/1.jpg" class="img-thumbnail" alt="">
            <h1 class="card-title pricing-card-title"><small class="text-muted fw-light"></small></h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li></li>
              <li></li>
              <li></li>
              <li></li>
            </ul>

            <form action="rate.php" method="post">
             <input type="hidden" class="form-control" name="teach" id="teach" value="6" >
             <button   type="submit" class="btn col222 btn-success">Оценить преподавателя</button>
            </form>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card mb-4 rounded-3 shadow-sm">
          <div class="card-header py-3">
            <h4 class="my-0 fw-normal">Направление: нидра</h4>


            <h4 class="my-0 fw-normal">Ирина Олобаева</h4>
          </div>
          <div class="card-body">
              <img src="img/2.jpg" class="img-thumbnail" alt="">
            <h1 class="card-title pricing-card-title"><small class="text-muted fw-light"></small></h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li></li>
              <li></li>
              <li></li>
              <li></li>
            </ul>
            <form action="rate.php" method="post">
             <input type="hidden" class="form-control" name="teach" id="teach" value="7" >
             <button   type="submit" class="btn col222 btn-success">Оценить преподавателя</button>
            </form>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card mb-4 rounded-3 shadow-sm">
          <div class="card-header py-3">
            <h4 class="my-0 fw-normal">Направление:  аштанга</h4>
            <h4 class="my-0 fw-normal">Алина Исыгбаева</h4>
          </div>
          <div class="card-body">
              <img src="img/3.jpg" class="img-thumbnail" alt="">
            <h1 class="card-title pricing-card-title"><small class="text-muted fw-light"></small></h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li></li>
              <li></li>
              <li></li>
              <li></li>
            </ul>
            <form action="rate.php" method="post">
             <input type="hidden" class="form-control" name="teach" id="teach" value="9" >
             <button   type="submit" class="btn col222 btn-success">Оценить преподавателя</button>
            </form>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card mb-4 rounded-3 shadow-sm">
          <div class="card-header py-3">
              <h4 class="my-0 fw-normal">Преподаватель Айенгара йоги</h4>
            <h4 class="my-0 fw-normal">Игнат Лоболовский</h4>
          </div>
          <div class="card-body">
              <img src="img/4.jpg" class="img-thumbnail" alt="">
            <h1 class="card-title pricing-card-title"><small class="text-muted fw-light"></small></h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li></li>
              <li></li>
              <li></li>
              <li></li>
            </ul>
            <form action="rate.php" method="post">
             <input type="hidden" class="form-control" name="teach" id="teach" value="12" >
             <button   type="submit" class="btn col222 btn-success">Оценить преподавателя</button>
            </form>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card mb-4 rounded-3 shadow-sm">
          <div class="card-header py-3">
            <h4 class="my-0 fw-normal">Йога Айенгара</h4>
          </div>
          <div class="card-body">
              <img src="img/5.jpg" class="img-thumbnail" alt="">
            <h1 class="card-title pricing-card-title"><small class="text-muted fw-light"></small></h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li></li>
              <li></li>
              <li></li>
              <li></li>
            </ul>
            <button type="button" class="w-100 btn btn-lg btn-primary">О направлении</button>
          </div>
        </div>
      </div>


    </div>
  </div>


 	<?php require "blocks/footer.php" ?>

 </body>
</html>
