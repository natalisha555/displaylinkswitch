<?php
include "read_and_export3.php";
?>
<!DOCTYPE HTML >
<html lang="ru">
 <head>

  <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">

<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="dns-prefetch" href="//netdna.bootstrapcdn.com">

<title> PHP web-site</title>

<style type="text/css">
BODY {
background: url(img/1.jpg) no-repeat  0px; /* Параметры фона */
}

</style>


 </head>
 <body>


	<?php require "blocks/header.php" ?>


        <div class="container">
        <br>
        <div class="col-sm-12">
        <div>
        <form action="#" method="post" class="color">
        <button type="submit" id="export" name="export3"
        value="Export to excel" class="btn color btn-success">Экспорт записанных пользователей в Excel</button>
        </form>
        </div>
        </div>
        <br/><br>





  <table  id=""
  style="display:none"
  class="hidde table table-striped table-bordered">
  <tr>
  <th>Дата</th>
  <th>Преподаватель</th>
  <th>Вид йоги</th>
  <th>Время</th>
  <th>Клиент</th>
  <th>Телефон</th>



  </tr>
  <tbody>
    <?php
  //  $check=0;
      //  $m=$classes[0]['date'];
$m="";
        foreach($classes as $class) { ?>
        <tr>
  <td> <?php    echo $class['date']; ?> </td>
  <td><?php echo $class ['fio']; ?></td>
  <td><?php echo $class ['type']; ?></td>
  <td>$<?php echo $class ['time']; ?></td>
  <td>$<?php echo $class ['name']; ?></td>
  <td>$<?php echo $class ['phone']; ?></td>

  </tr>
  <?php } ?>

  </table>





  <div class="container  mt-4" >

    <h1>Добавление классов</h1>

    <form action="validation-form.php/checkadding.php" method="post">

<br><br>
<input type="text" style="width:300px" class="form-control" name="type" id="type" placeholder="Введите направление " ><br>
<input type="text" style="width:300px" class="form-control" name="teacher" id="teacher" placeholder="Введите преподавателя " ><br>
<input type="time" style="width:300px" class="form-control" name="time" id="time" placeholder="Введите время занятия " ><br>
<input type="date" style="width:300px" class="form-control" name="date" id="date" placeholder="Введите дату занятия " ><br>

<br>

<button   type="submit" class="btn btn-success">Добавить</button>
  </form>

</div>
<br> <br> <br>

 	<?php require "blocks/footer.php" ?>

 </body>
</html>
