<?php
 $config = [
    'defaultFrom' => 'mymail@example.org',
    'onError'     => function($error, $message, $transport) { echo $error; },
    'afterSend'   => function($text, $message, $layer) { echo $text; },
    'transports'  => [
        // Сохранение всех писем в папке
        ['file', 'dir'  => __DIR__ .'/mails'],

        // Отправка писем через Yandex, используя SSL и авторизацию
        ['smtp', 'host' => 'smtp.yandex.ru', 'ssl' => true, 'port' => '465', 'login' => 'natadesu@yandex.ru', 'password' => 'vjzctcnhfk.,bvrf'],
    ],
];
?>
