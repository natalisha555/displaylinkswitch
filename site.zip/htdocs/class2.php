<?php
require_once 'class1.php';

class ListOfPeople{

protected $array_id = [];

public function getArray()
{

  return $this->array_id;
}


public function __construct($array_id)
{
  $servername = "localhost:3307";
  $database = "people";
  $username = "root";
  $password = "root";
  // Создаем соединение

  $conn = mysqli_connect($servername, $username, $password, $database);
  // Проверяем соединение
  if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
  }

  $arr=array();
  $i=0;

foreach($array_id as $elem){
  //$id=mysql_real_escape_string($elem);
  $check=$conn->query("SELECT id FROM `people`  where id='$elem' ");
  //if(!$check) echo $conn->error;

  if(mysqli_num_rows ($check)!=0){
  $arr[$i]=$elem;

  $i++;
  }

  }

  $this->array_id=$arr;


}


public function Examples()
{

  $servername = "localhost:3307";
  $database = "people";
  $username = "root";
  $password = "root";
  // Создаем соединение

  $conn = mysqli_connect($servername, $username, $password, $database);
  // Проверяем соединение
  if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
  }

  $arr=array();
  $i=0;

  foreach($this->array_id as $elem){

  //$id=mysql_real_escape_string($elem);
  $check=$conn->query("SELECT id, name,last_name, date_of_birth, gender, town_of_birth
     FROM `people`  where id='$elem' ");
  //if(!$check) echo $conn->error;

    if(mysqli_num_rows ($check)!=0){
      $dannie=$check->fetch_assoc();
      $id=$dannie['id'];
        $name=$dannie['name'];
          $last_name=$dannie['last_name'];
            $date_of_birth=$dannie['date_of_birth'];
              $gender=$dannie['gender'];
                $town_of_birth=$dannie['town_of_birth'];
         $arr[]=new Person($id, $name,$last_name, $date_of_birth, $gender, $town_of_birth);

  }

  }

  //var_dump($arr);

   return $arr;
}

}
$exam=array();
 $arra=[1,2,3,155];
  $Mam=new ListOfPeople($arra);
 $exam=$Mam->Examples();

foreach ($exam as $key->value)
{
  echo $ex;
}

?>
