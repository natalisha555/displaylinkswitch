<!DOCTYPE HTML >
<html lang="ru">
 <head>
  <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<meta http-equiv="X-UA-Compatible" content="ie=edge">

<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="dns-prefetch" href="//netdna.bootstrapcdn.com">
<link rel="stylesheet" href="css/style.css">
	<title> PHP web-site</title>
 </head>
 <body>

	<?php session_start();
   require "blocks/header.php";
    ?>

  <div class="container mt-4">
    <?php
      if($_SESSION['message']==''):
        ?>
    <h1>Форма авторизации</h1>
    <form action="validation-form.php/checkauth.php" method="post">
<input type="text" class="form-control" name="login" id="login" placeholder="Введите логин " ><br>
<input type="pass" class="form-control" name="pass" id="pass" placeholder="Введите пароль " ><br>


<button   type="submit" class="btn btn-success">Войти в аккаунт</button>
  </form>

  <a class="btn btn-outline-primary" href="registration.php">У меня еще нет аккаунта.Зарегистрироваться</a>
    </div>

  <?php else:?>
    <p> Привет, <?=$_SESSION['message']?>.Чтобы выйти, нажмите <a href="exit.php">здесь</a></p>
    <p> Чтобы перейти на главную, нажмите <a href="index.php">здесь</a></p>
  <?php endif;?>

 	<?php require "blocks/footer.php" ?>


 </body>
</html>
