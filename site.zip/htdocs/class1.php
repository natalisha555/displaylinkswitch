<?php
class Person
{
  private $id;
  private $name;
  private $last_name;
  private $date_of_birth;
  private $gender;
  private $town_of_birth;

  public function __construct($id, $name, $last_name, $date_of_birth, $gender, $town_of_birth)
  {


    $servername = "localhost:3307";
    $database = "people";
    $username = "root";
    $password = "root";
    // Создаем соединение

    $conn = mysqli_connect($servername, $username, $password, $database);
    // Проверяем соединение
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }


  //  $id=mysql_real_escape_string($id);
    $check=$conn->query("SELECT id, name,last_name, date_of_birth, gender, town_of_birth
       FROM `people`  where id='$id' ");

    //if(!$check) echo $conn->error;

    if(mysqli_num_rows ($check)==0){

list($year, $month, $day) = explode("-", $date_of_birth);

 if ( ctype_alpha($name)) {
   echo "Имя $name состоит не только из букв!\n";
 } elseif (ctype_alpha($last_name)) {
   echo "Фамилия $last_name состоит не только из букв!\n";
 } elseif (checkdate($month, $day, $year)!='true' ||   $date_of_birth > date('Y-m-d')){
    echo "Дата рождения некорректна!";
} else {
      $conn->query("INSERT into people (id, name,last_name, date_of_birth, gender, town_of_birth)
      values ('$id', '$name', '$last_name','$date_of_birth', '$gender', '$town_of_birth')
       ");
}

    }else {

        $dannie=$check->fetch_assoc();

        $this->id = $dannie['id'];
        $this->name = $dannie['name'];
        $this->last_name = $dannie['last_name'];
        $this->date_of_birth = $dannie['date_of_birth'];
        $this->gender = $dannie['gender'];
        $this->town_of_birth = $dannie['town_of_birth'];



    }





  }


  public function getFirstName()
    {
      return $this->name;
    }

    public function getLastName()
    {
      return $this->last_name;
    }

    public function getDateOfBirth()
    {
      return $this->date_of_birth;
    }

    public function getGender()
    {
      return $this->gender;
    }


      public function addToDB()
      {

            $servername = "localhost:3307";
            $database = "people";
            $username = "root";
            $password = "root";
            // Создаем соединение

            $conn = mysqli_connect($servername, $username, $password, $database);
            // Проверяем соединение
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }



            $conn->query("INSERT into people (id, name,last_name, date_of_birth, gender, town_of_birth)
            values ('$this->id', '$this->name', '$this->last_name','$this->date_of_birth', '$this->gender', '$this->town_of_birth')
             ");


      }



      public function deleteFromDB($id)
      {
        $servername = "localhost:3307";
        $database = "people";
        $username = "root";
        $password = "root";
        // Создаем соединение

        $conn = mysqli_connect($servername, $username, $password, $database);
        // Проверяем соединение
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        //$id=mysql_real_escape_string($id);
        $conn->query("DELETE from  people where id='$id' ");

      }


      static function convertDateToAge($date)
      {

        $birthday_timestamp = strtotime($date);
       $age = date('Y') - date('Y', $birthday_timestamp);
       if (date('md', $birthday_timestamp) > date('md')) {
         $age--;
       }
       return $age;

      }



      static function convertGender($gend)
      {

      if ($gend==0){
        $gender='муж';
      } else {
        $gender='жен';
      }

      return $gender;

      }



    public function formatPerson($toChange)
    {


     if ($toChange=='gend')
     {
       $this->gender=Person::convertGender($this->gender);}
     if($toChange=='date')
     {
        $this->date_of_birth=Person::convertDateToAge($this->date_of_birth);
     }
     if($toChange=='gd')
     {
        $this->gender=Person::convertGender($this->gender);
        $this->date_of_birth=Person::convertDateToAge($this->date_of_birth);
     }

     return $this;
    }



    }




    //  $Mama=new Person(22,'Нтао','Леонар','2020-10-18',1,'Pomel');
      //$Mama->addToDB();
    //  $Mama->deleteFromDB(22);
    // echo $Mama->getDateOfBirth();
    // echo ' ';
     //echo $Mama->getGender();
      //  echo ' ';
  //  $Mama->formatPerson('gd');
  //  echo $Mama->getDateOfBirth();
      // echo ' ';
    // echo $Mama->getGender();

    ?>
