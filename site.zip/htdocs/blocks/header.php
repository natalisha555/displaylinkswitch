<div class="d-flex flex-column flex-md-row align-items-center  p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm">
  <h5 class="my-0 mr-md-auto font-weight-normal">YogaHall</h5>
  <nav class="my-2 my-md-0 mr-md-3">

<style>
.mybitter{
  height:60px;
  width:150px;
  margin-left:20px;
}
</style>
    <?php
    session_start();
      if($_SESSION['message']=='admin'):   ?>
      <a class="p-2 text-dark" href="admin_tool.php">Для администраторов</a>
      <?php endif;?>
    <?php
       if($_SESSION['message']=='director'): ?>
          <a class="p-2 text-dark" href="director.php">Управление</a>

    <?php endif;?>

    <a class="p-2 text-dark" href="/">Главная</a>

    <?php
       if($_SESSION['message']!=''): ?>

          <a class="p-2 text-dark" href="my_notes.php?name=<?php echo $_SESSION['message']?>">Мои записи</a>

    <?php endif;?>

    <a class="p-2 text-dark" href="types_of_yoga.php">Наши направления</a>
    <a class="p-2 text-dark" href="zapis.php">Записаться на занятие</a>
    <a class="p-2 text-dark" href="map.php">Наше расположение</a>
    <a class="p-2 text-dark" href="teachers.php">Наши преподаватели</a>
    <a class="p-2 text-dark" href="prices.php">Цены</a>
    <a class="p-2 text-dark" href="contacts.php">Контакты</a>
  </nav>

  <?php

    if($_SESSION['message']==''):   ?>
  <a class="btn btn-outline-primary" href="authorization.php">Войти</a>
<?php else:?>
  <p>Привет, <?=$_SESSION['message']?> ! <br></p> <br>
    <a class="btn btn-outline-primary" href="exit.php">Выйти</a>
    <a class="btn mybitter btn-outline-primary" style="" href="choosing.php">Подбор преподавателя</a>
      <a class="btn mybitter btn-outline-primary"  href="subscribe.php">Подписаться на рассылку студии</a>
<?php endif;?>


</div>
