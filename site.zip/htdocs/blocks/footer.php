<footer id="colophon" class="site-footer" role="contentinfo">
           <div class="wrapper footer-wrapper">
               <div class="footer-copyright border text-center">
           <p>© 2016-<?php echo date("Y"); ?> Все права защищены.</p>
                                       <div class="site-info">
                                       </div><!-- .site-info -->
               </div>


       </footer>
