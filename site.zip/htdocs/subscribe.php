<?php
$servername = "localhost:3307";
$database = "yogahall";
$username = "root";
$password = "root";
// Создаем соединение

$conn = mysqli_connect($servername, $username, $password, $database);
// Проверяем соединение
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

session_start();
$nam=$_SESSION['message'];

$i=0;
$result=$conn->query("SELECT  email from users where name='$nam' ");


$rws = mysqli_fetch_assoc($result);
  $mail = $rws['email'];


//$m=$conn->query("insert into emails (email,createdAt) values ('$mail', date('d.m.Y H:i:s')) ");
$conn->query("INSERT INTO emails (email) VALUES ('$mail')");

header('Location: /index.php');


 ?>
