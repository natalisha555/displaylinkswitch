<?php

$servername = "localhost:3307";
$database = "yogahall";
$username = "root";
$password = "root";
// Создаем соединение

$conn = mysqli_connect($servername, $username, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


//mysql_query("SET_NAMES 'cp1251'");

$date=date('Y-m-d');

$result=$conn->query("SELECT tabl.date as date,tabl.fio as fio, types_of_yoga.type_of_yoga as type ,classes.time as time,
 users.name, users.phone
 from classes , types_of_yoga ,
 teachers, ( SELECT teachers.fio as fio, date from teachers inner join
  classes on classes.idteacher=teachers.idteacher group by date, teachers.fio)
   as tabl, note,users
    where classes.idtype=types_of_yoga.idtype
    and classes.idteacher=teachers.idteacher
    and classes.idclass=note.idclass
    and note.iduser=users.iduser
    and tabl.fio=teachers.fio
    and classes.date>='$date'");


$classes = array();

// Сохраняем записи таблицы в массив
while( $row = $result->fetch_assoc() ) {
$classes[] = $row;

}

$i=0;
$m= '';
$k='';
$l='';
$t='';

foreach($classes as $class) {

 if($class ['date']!=$m){
//$class['date']= $class ['date'];
           $m=$class ['date'];

            $k=$class['fio'];
           $l=$class['type'];
           $t=$class['time'];

}
else {
              $classes[$i]['date']="";

               if($class ['fio']!=$k){

                $k=$class ['fio'];
                $l=$class['type'];
                 $t=$class['time'];
               } else{
                            $classes[$i]['fio']="";

                             if($class ['type']!=$l){
                             $l =$class ['type'];
                             $t=$class['time'];
                              }
                           else{
                                   $classes[$i]['type']="";
                                   if($class ['time']!=$t){

                                   $t =$class ['time'];
                                    }
                                 else{

                                         $classes[$i]['time']="";
                                         //trim(str_replace('$','',$classes[$i]['time'));
                                       }


                            }

                 }



}
$i++;

}




// Проверяем, нажата ли кнопка экспорта
if(isset($_POST["export3"])) {
// Определим имя файла с текущей датой
$fileName = "Записанные пользователи-".date('d-m-Y').".txt";

// Устанавливаем информацию заголовка для экспорта данных в формате Excel
header('Content-Type: application/vnd.ms-excel; charset=utf-8');
header('Content-Disposition: attachment; filename='.$fileName);


// Устанавливаем переменную в false для заголовка
$heading = false;

// Добавляем данные таблицы MySQL в файл Excel

if(!empty($classes)) {
foreach($classes as $class) {
if(!$heading) {
echo implode("\t", array_keys($class)) . "\n";
$heading = true;
}
echo implode("\t", array_values($class)) . "\n";
}
}
exit();
}




?>
